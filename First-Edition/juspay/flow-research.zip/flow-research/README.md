


Key ideas:


- Flows can be constructed from templates
- Input Payment Data type and Payment Result type are specific to a flow (using associated types)
