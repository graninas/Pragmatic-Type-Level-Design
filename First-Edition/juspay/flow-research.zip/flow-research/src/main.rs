mod domain;
mod api;
mod application;
mod assets;
mod common_types;

fn main() {
  println!("Hello, world!");
}
